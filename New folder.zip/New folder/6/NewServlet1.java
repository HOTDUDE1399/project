package timepass;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
* Servlet implementation class NewServlet1
*/
@WebServlet("/NewServlet1")
public class NewServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

/**
* @see HttpServlet#HttpServlet()
*/
public NewServlet1() {
super();
// TODO Auto-generated constructor stub
}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
/* TODO output your page here. You may use following sample code. */
response.setContentType("text/html;charset=UTF-8");
PrintWriter out = response.getWriter();

HttpSession session=request.getSession(false);
String nm=(String)session.getAttribute("user");
out.print("<font size=6>");
out.print("Hello"+nm+"welcome to next page");
out.print("</font>");
out.close();
session.setAttribute("user",nm);
}
catch(IOException e)
{
System.out.print(e);
}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
