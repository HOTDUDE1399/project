package timepass;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
* Servlet implementation class NewServlet
*/
@WebServlet("/NewServlet")
public class NewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

/**
* @see HttpServlet#HttpServlet()
*/
public NewServlet() {
super();
// TODO Auto-generated constructor stub
}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
	            /* TODO output your page here. You may use following sample code. */
	            response.setContentType("text/html;charset=UTF-8");
	            PrintWriter out = response.getWriter();
	                out.println("<font size=6>");
	
	                String nm=request.getParameter("user_name");
	                out.print("Welcome to our web"+nm);
	
	                HttpSession session=request.getSession();
	                session.setAttribute("user",nm);
	                out.print("<br><br><a href='http://localhost:8080/WebApplication5/NewServlet1'>Click to proceed</a>");
	                out.print("</font>");
	            }
	        catch(IOException e)
	        {
	            System.out.print(e);
	        }
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

public String getServletInfo() {
return "Short description";
}
}

