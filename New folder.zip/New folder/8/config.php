<?php
$database = 'localhost';
$dbName = 'Sample';
$dbUser = 'root';
$dbPass = '';
$mysqli = mysqli_connect($database, $dbUser, $dbPass, $dbName);
?>
